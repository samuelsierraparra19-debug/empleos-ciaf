import { useState, useEffect, useRef } from "react";

// ── CIAF Brand Colors ──────────────────────────────────────────────────────
// Primary:  #C8102E  (rojo CIAF)
// Dark:     #1A1A1A  (negro institucional)
// Light:    #F5F5F5  (fondo claro)
// Accent:   #FF6B35  (naranja cálido)
// White:    #FFFFFF
// ──────────────────────────────────────────────────────────────────────────

const JOBS = [
  { id: 1, title: "Desarrollador Frontend Jr.", company: "TechCo", logo: "TC", location: "Bogotá", type: "Tiempo completo", career: "Sistemas", level: "Técnico", match: 95, tags: ["React", "CSS", "Git"] },
  { id: 2, title: "Analista de Datos", company: "DataVision", logo: "DV", location: "Remoto", type: "Prácticas", career: "Sistemas", level: "Tecnólogo", match: 88, tags: ["Excel", "Python", "SQL"] },
  { id: 3, title: "Diseñador UX/UI", company: "CreativeHub", logo: "CH", location: "Medellín", type: "Medio tiempo", career: "Diseño", level: "Técnico", match: 76, tags: ["Figma", "Illustrator"] },
  { id: 4, title: "Asistente Contable", company: "FinanzasPro", logo: "FP", location: "Bogotá", type: "Prácticas", career: "Contabilidad", level: "Tecnólogo", match: 82, tags: ["Excel", "SAP"] },
  { id: 5, title: "Community Manager", company: "BrandLab", logo: "BL", location: "Remoto", type: "Freelance", career: "Marketing", level: "Técnico", match: 70, tags: ["Instagram", "Canva", "Métricas"] },
  { id: 6, title: "Soporte TI", company: "NetSolve", logo: "NS", location: "Bogotá", type: "Tiempo completo", career: "Sistemas", level: "Técnico", match: 91, tags: ["Redes", "Windows", "Soporte"] },
];

const STEPS = [
  { icon: "👤", title: "Crea tu perfil", desc: "Agrega tus habilidades, proyectos y logros académicos en minutos." },
  { icon: "🎯", title: "Match inteligente", desc: "Nuestro sistema te conecta con ofertas que realmente se ajustan a ti." },
  { icon: "✅", title: "Validación docente", desc: "Tus profesores avalan tus competencias y potencian tu perfil." },
  { icon: "🚀", title: "Consigue el empleo", desc: "Postúlate con un perfil que habla por ti y destaca entre los demás." },
];

const STATS = [
  { value: "1.200+", label: "Estudiantes activos" },
  { value: "340+", label: "Empresas aliadas" },
  { value: "89%", label: "Tasa de match" },
  { value: "48h", label: "Tiempo promedio de respuesta" },
];

// ── Helpers ────────────────────────────────────────────────────────────────

function getInitials(name) {
  if (!name) return "?";
  return name.trim().split(" ").map(w => w[0]).slice(0, 2).join("").toUpperCase();
}

function getMatchColor(p) {
  if (p >= 90) return "#C8102E";
  if (p >= 75) return "#FF6B35";
  return "#888";
}

// ── Match Bar ──────────────────────────────────────────────────────────────
function MatchBar({ percent, animated }) {
  const [width, setWidth] = useState(0);
  useEffect(() => {
    if (animated) setTimeout(() => setWidth(percent), 200);
    else setWidth(percent);
  }, [animated, percent]);
  const color = getMatchColor(percent);
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
      <div style={{ flex: 1, height: 5, background: "#E8E8E8", borderRadius: 99, overflow: "hidden" }}>
        <div style={{ height: "100%", width: `${width}%`, background: color, borderRadius: 99, transition: "width 0.9s cubic-bezier(.4,2,.6,1)" }} />
      </div>
      <span style={{ fontSize: 12, fontWeight: 700, color, minWidth: 36 }}>{percent}%</span>
    </div>
  );
}

// ── Job Card ───────────────────────────────────────────────────────────────
function JobCard({ job, onApply }) {
  const [hovered, setHovered] = useState(false);
  return (
    <div
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
      style={{
        background: "#FFFFFF",
        border: `1.5px solid ${hovered ? "#C8102E" : "#EBEBEB"}`,
        borderRadius: 16,
        padding: "20px",
        transition: "all 0.22s ease",
        transform: hovered ? "translateY(-4px)" : "translateY(0)",
        cursor: "pointer",
        position: "relative",
        overflow: "hidden",
        boxShadow: hovered ? "0 12px 32px rgba(200,16,46,0.10)" : "0 2px 8px rgba(0,0,0,0.05)",
      }}
    >
      {job.match >= 90 && (
        <div style={{ position: "absolute", top: 12, right: 12, background: "#C8102E", color: "#fff", fontSize: 10, fontWeight: 800, padding: "3px 10px", borderRadius: 99, letterSpacing: 1 }}>
          TOP MATCH
        </div>
      )}
      <div style={{ display: "flex", gap: 14, alignItems: "flex-start", marginBottom: 14 }}>
        <div style={{ width: 46, height: 46, borderRadius: 12, background: hovered ? "#C8102E" : "#1A1A1A", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 13, fontWeight: 900, color: "#fff", flexShrink: 0, transition: "background 0.22s" }}>
          {job.logo}
        </div>
        <div>
          <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 15, fontWeight: 700, color: "#1A1A1A", lineHeight: 1.25 }}>{job.title}</div>
          <div style={{ fontSize: 13, color: "#888", marginTop: 3 }}>{job.company} · {job.location}</div>
        </div>
      </div>
      <div style={{ display: "flex", gap: 6, flexWrap: "wrap", marginBottom: 14 }}>
        <span style={{ fontSize: 11, padding: "3px 10px", borderRadius: 99, background: "rgba(200,16,46,0.08)", color: "#C8102E", border: "1px solid rgba(200,16,46,0.15)", fontWeight: 600 }}>{job.type}</span>
        <span style={{ fontSize: 11, padding: "3px 10px", borderRadius: 99, background: "#F5F5F5", color: "#666", fontWeight: 600 }}>{job.career}</span>
        {job.tags.map(t => (
          <span key={t} style={{ fontSize: 11, padding: "3px 10px", borderRadius: 99, background: "#F0F0F0", color: "#888", fontWeight: 500 }}>{t}</span>
        ))}
      </div>
      <div style={{ marginBottom: 14 }}>
        <div style={{ fontSize: 10, color: "#AAA", marginBottom: 5, fontWeight: 700, letterSpacing: 1 }}>COMPATIBILIDAD</div>
        <MatchBar percent={job.match} animated />
      </div>
      <button
        onClick={() => onApply(job)}
        style={{
          width: "100%", padding: "10px 0", borderRadius: 10, border: hovered ? "none" : "1.5px solid #EBEBEB",
          cursor: "pointer",
          background: hovered ? "#C8102E" : "#F8F8F8",
          color: hovered ? "#fff" : "#555",
          fontWeight: 700, fontSize: 13,
          transition: "all 0.22s ease", letterSpacing: 0.3,
          fontFamily: "inherit",
        }}
      >
        {hovered ? "Postularme ahora →" : "Ver oferta"}
      </button>
    </div>
  );
}

// ── Profile View (shown after profile creation) ────────────────────────────
function ProfileView({ data, onClose, onShowJobs }) {
  const skillList = data.skills ? data.skills.split(",").map(s => s.trim()).filter(Boolean) : [];
  const matchedJobs = JOBS.filter(j =>
    skillList.some(sk => j.tags.some(t => t.toLowerCase().includes(sk.toLowerCase()))) ||
    (data.career && j.career.toLowerCase().includes(data.career.toLowerCase().split(" ")[0]))
  ).slice(0, 3);

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(26,26,26,0.7)", backdropFilter: "blur(10px)", zIndex: 1000, display: "flex", alignItems: "center", justifyContent: "center", padding: 20, overflowY: "auto" }}>
      <div style={{ background: "#FFFFFF", borderRadius: 24, maxWidth: 540, width: "100%", position: "relative", overflow: "hidden", boxShadow: "0 24px 64px rgba(0,0,0,0.18)" }}>
        
        {/* Header rojo */}
        <div style={{ background: "#C8102E", padding: "36px 32px 60px", position: "relative", overflow: "hidden" }}>
          <div style={{ position: "absolute", top: -30, right: -30, width: 160, height: 160, borderRadius: "50%", background: "rgba(255,255,255,0.06)" }} />
          <div style={{ position: "absolute", bottom: -40, left: -20, width: 120, height: 120, borderRadius: "50%", background: "rgba(0,0,0,0.08)" }} />
          <button onClick={onClose} style={{ position: "absolute", top: 16, right: 16, background: "rgba(255,255,255,0.15)", border: "none", color: "#fff", fontSize: 16, cursor: "pointer", borderRadius: "50%", width: 32, height: 32, display: "flex", alignItems: "center", justifyContent: "center" }}>✕</button>
          <div style={{ position: "relative", zIndex: 1 }}>
            <div style={{ width: 72, height: 72, borderRadius: "50%", background: "#1A1A1A", border: "3px solid rgba(255,255,255,0.3)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 26, fontWeight: 800, color: "#fff", marginBottom: 16, fontFamily: "'Syne', sans-serif" }}>
              {getInitials(data.name)}
            </div>
            <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 24, fontWeight: 800, color: "#fff", marginBottom: 4 }}>{data.name || "Estudiante CIAF"}</div>
            <div style={{ fontSize: 14, color: "rgba(255,255,255,0.75)", marginBottom: 8 }}>{data.career || "Programa CIAF"}</div>
            <div style={{ display: "inline-flex", alignItems: "center", gap: 6, background: "rgba(255,255,255,0.15)", borderRadius: 99, padding: "4px 12px", fontSize: 12, color: "#fff", fontWeight: 600 }}>
              <span style={{ width: 6, height: 6, borderRadius: "50%", background: "#4ADE80", display: "inline-block" }} />
              Perfil activo · CIAF Empleo
            </div>
          </div>
        </div>

        {/* Contenido */}
        <div style={{ padding: "0 32px 32px", marginTop: -28 }}>
          
          {/* Sobre mí */}
          {data.bio && (
            <div style={{ background: "#F8F8F8", borderRadius: 14, padding: "18px 20px", marginBottom: 20, border: "1px solid #EBEBEB" }}>
              <div style={{ fontSize: 10, fontWeight: 700, color: "#AAA", letterSpacing: 1, marginBottom: 8 }}>SOBRE MÍ</div>
              <p style={{ fontSize: 14, color: "#444", lineHeight: 1.6, margin: 0 }}>{data.bio}</p>
            </div>
          )}

          {/* Habilidades */}
          {skillList.length > 0 && (
            <div style={{ marginBottom: 20 }}>
              <div style={{ fontSize: 10, fontWeight: 700, color: "#AAA", letterSpacing: 1, marginBottom: 12 }}>HABILIDADES</div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 8 }}>
                {skillList.map((sk, i) => (
                  <span key={i} style={{ padding: "6px 14px", borderRadius: 99, background: i === 0 ? "#C8102E" : "#1A1A1A", color: "#fff", fontSize: 12, fontWeight: 600 }}>{sk}</span>
                ))}
              </div>
            </div>
          )}

          {/* Matches sugeridos */}
          {matchedJobs.length > 0 && (
            <div style={{ marginBottom: 24 }}>
              <div style={{ fontSize: 10, fontWeight: 700, color: "#AAA", letterSpacing: 1, marginBottom: 12 }}>OFERTAS RECOMENDADAS PARA TI</div>
              <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                {matchedJobs.map(job => (
                  <div key={job.id} style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 14px", background: "#F8F8F8", borderRadius: 12, border: "1px solid #EBEBEB" }}>
                    <div style={{ width: 36, height: 36, borderRadius: 9, background: "#1A1A1A", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 11, fontWeight: 900, color: "#fff", flexShrink: 0 }}>{job.logo}</div>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontSize: 13, fontWeight: 700, color: "#1A1A1A" }}>{job.title}</div>
                      <div style={{ fontSize: 11, color: "#888" }}>{job.company} · {job.location}</div>
                    </div>
                    <div style={{ fontSize: 13, fontWeight: 800, color: "#C8102E" }}>{job.match}%</div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* CTA */}
          <button
            onClick={() => { onClose(); onShowJobs(); }}
            style={{ width: "100%", padding: "14px 0", borderRadius: 12, border: "none", background: "#C8102E", color: "#fff", fontSize: 15, cursor: "pointer", fontWeight: 800, fontFamily: "inherit", letterSpacing: 0.3, transition: "opacity 0.2s" }}
            onMouseEnter={e => e.target.style.opacity = "0.88"}
            onMouseLeave={e => e.target.style.opacity = "1"}
          >
            Ver todas las ofertas →
          </button>
        </div>
      </div>
    </div>
  );
}

// ── Profile Builder Modal ──────────────────────────────────────────────────
function ProfileBuilder({ onClose, onProfileReady }) {
  const [step, setStep] = useState(0);
  const [data, setData] = useState({ name: "", career: "", skills: "", bio: "" });
  const fields = [
    { key: "name", label: "¿Cuál es tu nombre?", placeholder: "Ej: María Fernanda González", icon: "👤" },
    { key: "career", label: "¿Qué carrera estudias?", placeholder: "Ej: Tecnología en Sistemas", icon: "🎓" },
    { key: "skills", label: "¿Cuáles son tus habilidades clave?", placeholder: "Ej: React, Figma, Python, Excel...", icon: "⚡" },
    { key: "bio", label: "Cuéntanos algo sobre ti", placeholder: "Tu historia en una frase...", icon: "✍️" },
  ];
  const current = fields[step];
  const done = step >= fields.length;

  return (
    <div style={{ position: "fixed", inset: 0, background: "rgba(26,26,26,0.75)", backdropFilter: "blur(12px)", zIndex: 1000, display: "flex", alignItems: "center", justifyContent: "center", padding: 20 }}>
      <div style={{ background: "#FFFFFF", border: "1.5px solid #EBEBEB", borderRadius: 24, padding: 40, maxWidth: 460, width: "100%", position: "relative", boxShadow: "0 24px 64px rgba(0,0,0,0.14)" }}>
        <button onClick={onClose} style={{ position: "absolute", top: 16, right: 16, background: "#F0F0F0", border: "none", color: "#888", fontSize: 16, cursor: "pointer", borderRadius: "50%", width: 32, height: 32, display: "flex", alignItems: "center", justifyContent: "center" }}>✕</button>
        
        {!done ? (
          <>
            <div style={{ marginBottom: 32 }}>
              {/* Progress */}
              <div style={{ display: "flex", gap: 6, marginBottom: 28 }}>
                {fields.map((_, i) => (
                  <div key={i} style={{ flex: 1, height: 3, borderRadius: 99, background: i <= step ? "#C8102E" : "#E8E8E8", transition: "background 0.3s" }} />
                ))}
              </div>
              <div style={{ fontSize: 32, marginBottom: 12 }}>{current.icon}</div>
              <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 22, fontWeight: 700, color: "#1A1A1A", marginBottom: 4 }}>{current.label}</div>
              <div style={{ fontSize: 12, color: "#AAA" }}>Paso {step + 1} de {fields.length}</div>
            </div>

            <input
              value={data[current.key]}
              onChange={e => setData({ ...data, [current.key]: e.target.value })}
              onKeyDown={e => { if (e.key === "Enter" && data[current.key]) { if (step < fields.length - 1) setStep(s => s + 1); else setStep(fields.length); } }}
              placeholder={current.placeholder}
              autoFocus
              style={{ width: "100%", background: "#F8F8F8", border: "1.5px solid #E0E0E0", borderRadius: 12, padding: "14px 16px", color: "#1A1A1A", fontSize: 15, outline: "none", boxSizing: "border-box", fontFamily: "inherit", transition: "border-color 0.2s" }}
            />
            <div style={{ display: "flex", gap: 10, marginTop: 20 }}>
              {step > 0 && (
                <button onClick={() => setStep(s => s - 1)} style={{ flex: 1, padding: "13px 0", borderRadius: 12, border: "1.5px solid #E0E0E0", background: "none", color: "#888", fontSize: 14, cursor: "pointer", fontWeight: 600, fontFamily: "inherit" }}>← Atrás</button>
              )}
              <button
                onClick={() => { if (step < fields.length - 1) setStep(s => s + 1); else setStep(fields.length); }}
                disabled={!data[current.key]}
                style={{ flex: 2, padding: "13px 0", borderRadius: 12, border: "none", background: data[current.key] ? "#C8102E" : "#E0E0E0", color: data[current.key] ? "#fff" : "#AAA", fontSize: 14, cursor: data[current.key] ? "pointer" : "not-allowed", fontWeight: 800, fontFamily: "inherit", transition: "background 0.2s" }}
              >
                {step < fields.length - 1 ? "Siguiente →" : "Crear perfil 🚀"}
              </button>
            </div>
          </>
        ) : (
          /* Éxito */
          <div style={{ textAlign: "center" }}>
            <div style={{ width: 72, height: 72, borderRadius: "50%", background: "#C8102E", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 28, fontWeight: 800, color: "#fff", margin: "0 auto 20px", fontFamily: "'Syne', sans-serif" }}>
              {getInitials(data.name)}
            </div>
            <div style={{ fontFamily: "'Syne', sans-serif", fontSize: 22, fontWeight: 700, color: "#1A1A1A", marginBottom: 6 }}>¡Perfil creado, {data.name.split(" ")[0]}!</div>
            <div style={{ fontSize: 14, color: "#888", marginBottom: 28 }}>Hemos encontrado <strong style={{ color: "#C8102E" }}>12 ofertas</strong> compatibles con tu perfil.</div>
            <button
              onClick={() => onProfileReady(data)}
              style={{ width: "100%", padding: "14px 0", borderRadius: 12, border: "none", background: "#C8102E", color: "#fff", fontSize: 15, cursor: "pointer", fontWeight: 800, fontFamily: "inherit" }}
            >
              Ver mi perfil →
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

// ── Main App ───────────────────────────────────────────────────────────────
export default function App() {
  const [activeTab, setActiveTab] = useState("inicio");
  const [filter, setFilter] = useState({ career: "all", type: "all" });
  const [showBuilder, setShowBuilder] = useState(false);
  const [profileData, setProfileData] = useState(null);
  const [showProfileView, setShowProfileView] = useState(false);
  const [notification, setNotification] = useState(null);
  const [menuOpen, setMenuOpen] = useState(false);

  const showNotif = (msg) => {
    setNotification(msg);
    setTimeout(() => setNotification(null), 3000);
  };

  const handleProfileReady = (data) => {
    setProfileData(data);
    setShowBuilder(false);
    setShowProfileView(true);
  };

  const filteredJobs = JOBS.filter(j =>
    (filter.career === "all" || j.career === filter.career) &&
    (filter.type === "all" || j.type === filter.type)
  );

  const tabs = [
    { id: "inicio", label: "Inicio" },
    { id: "ofertas", label: "Ofertas" },
    { id: "como-funciona", label: "¿Cómo funciona?" },
    { id: "estadisticas", label: "Impacto" },
  ];

  return (
    <>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;0,9..40,600;1,9..40,400&display=swap');
        * { margin: 0; padding: 0; box-sizing: border-box; }
        html { scroll-behavior: smooth; }
        body { background: #F5F5F5; color: #1A1A1A; font-family: 'DM Sans', sans-serif; min-height: 100vh; }
        .syne { font-family: 'Syne', sans-serif; }
        ::-webkit-scrollbar { width: 5px; }
        ::-webkit-scrollbar-track { background: #F0F0F0; }
        ::-webkit-scrollbar-thumb { background: #C8102E; border-radius: 99px; }
        input:focus { border-color: #C8102E !important; box-shadow: 0 0 0 3px rgba(200,16,46,0.08) !important; }
        @keyframes fadeUp { from { opacity:0; transform:translateY(24px); } to { opacity:1; transform:translateY(0); } }
        @keyframes pulse { 0%,100% { opacity:1; } 50% { opacity:0.5; } }
        @keyframes float { 0%,100% { transform:translateY(0px); } 50% { transform:translateY(-10px); } }
        @keyframes slideIn { from { transform:translateX(120px); opacity:0; } to { transform:translateX(0); opacity:1; } }
        .fade-up { animation: fadeUp 0.55s ease forwards; }
        .float { animation: float 4s ease-in-out infinite; }
        .nav-btn { transition: all 0.18s ease; }
        .nav-btn:hover { color: #C8102E !important; }
      `}</style>

      {/* NOTIFICACIÓN */}
      {notification && (
        <div style={{ position: "fixed", top: 24, right: 24, zIndex: 9999, background: "#C8102E", color: "#fff", padding: "14px 22px", borderRadius: 12, fontWeight: 700, fontSize: 14, animation: "slideIn 0.3s ease", boxShadow: "0 8px 32px rgba(200,16,46,0.25)", display: "flex", alignItems: "center", gap: 8 }}>
          ✅ {notification}
        </div>
      )}

      {/* MODALES */}
      {showBuilder && (
        <ProfileBuilder
          onClose={() => setShowBuilder(false)}
          onProfileReady={handleProfileReady}
        />
      )}
      {showProfileView && profileData && (
        <ProfileView
          data={profileData}
          onClose={() => setShowProfileView(false)}
          onShowJobs={() => setActiveTab("ofertas")}
        />
      )}

      {/* NAVBAR */}
      <nav style={{ position: "sticky", top: 0, zIndex: 100, background: "rgba(255,255,255,0.92)", backdropFilter: "blur(16px)", borderBottom: "1px solid #EBEBEB", padding: "0 24px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto", display: "flex", alignItems: "center", justifyContent: "space-between", height: 64 }}>
          
          {/* Logo */}
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ width: 34, height: 34, borderRadius: 9, background: "#C8102E", display: "flex", alignItems: "center", justifyContent: "center" }}>
              <span style={{ fontSize: 17 }}>💼</span>
            </div>
            <div>
              <span className="syne" style={{ fontWeight: 800, fontSize: 16, letterSpacing: -0.5, color: "#1A1A1A" }}>
                Bolsa de Empleo <span style={{ color: "#C8102E" }}>CIAF</span>
              </span>
            </div>
          </div>

          {/* Desktop nav */}
          <div style={{ display: "flex", gap: 2 }}>
            {tabs.map(t => (
              <button key={t.id} onClick={() => setActiveTab(t.id)} className="nav-btn" style={{
                padding: "8px 16px", borderRadius: 99, border: "none", cursor: "pointer", fontSize: 13, fontWeight: 600, fontFamily: "inherit",
                background: activeTab === t.id ? "rgba(200,16,46,0.08)" : "none",
                color: activeTab === t.id ? "#C8102E" : "#666",
              }}>{t.label}</button>
            ))}
          </div>

          {/* CTA + perfil */}
          <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
            {profileData && (
              <button onClick={() => setShowProfileView(true)} style={{ width: 36, height: 36, borderRadius: "50%", background: "#C8102E", border: "none", color: "#fff", fontWeight: 800, fontSize: 13, cursor: "pointer", fontFamily: "'Syne', sans-serif", display: "flex", alignItems: "center", justifyContent: "center" }}>
                {getInitials(profileData.name)}
              </button>
            )}
            <button onClick={() => setShowBuilder(true)} style={{ padding: "9px 20px", borderRadius: 99, border: "none", background: "#C8102E", color: "#fff", fontWeight: 700, fontSize: 13, cursor: "pointer", fontFamily: "inherit" }}>
              {profileData ? "Editar perfil" : "Crear perfil →"}
            </button>
          </div>
        </div>
      </nav>

      <div style={{ maxWidth: 1100, margin: "0 auto", padding: "0 24px" }}>

        {/* ═══ INICIO ═══════════════════════════════════════════════════════ */}
        {activeTab === "inicio" && (
          <div>
            {/* HERO */}
            <div style={{ paddingTop: 80, paddingBottom: 72, position: "relative" }}>
              {/* Decoración */}
              <div style={{ position: "absolute", top: 40, right: -60, width: 340, height: 340, borderRadius: "50%", background: "radial-gradient(ellipse, rgba(200,16,46,0.06) 0%, transparent 70%)", pointerEvents: "none" }} />
              <div style={{ position: "absolute", bottom: 0, left: -40, width: 220, height: 220, borderRadius: "50%", background: "radial-gradient(ellipse, rgba(255,107,53,0.07) 0%, transparent 70%)", pointerEvents: "none" }} />

              <div className="fade-up" style={{ textAlign: "center", position: "relative" }}>
                <div style={{ display: "inline-flex", alignItems: "center", gap: 8, background: "rgba(200,16,46,0.07)", border: "1px solid rgba(200,16,46,0.15)", borderRadius: 99, padding: "6px 18px", marginBottom: 30, fontSize: 12, color: "#C8102E", fontWeight: 700, letterSpacing: 1 }}>
                  <span style={{ width: 6, height: 6, borderRadius: "50%", background: "#C8102E", display: "inline-block", animation: "pulse 2s infinite" }} />
                  BOLSA DE EMPLEO CIAF — BETA ACTIVA
                </div>

                <h1 className="syne" style={{ fontSize: "clamp(36px, 5.5vw, 68px)", fontWeight: 800, lineHeight: 1.06, letterSpacing: -2, marginBottom: 22, maxWidth: 760, margin: "0 auto 22px" }}>
                  Tu talento{" "}
                  <span style={{ color: "#C8102E" }}>CIAF</span><br />
                  habla por ti
                </h1>

                <p style={{ fontSize: 17, color: "#777", maxWidth: 500, margin: "0 auto 40px", lineHeight: 1.65, fontWeight: 400 }}>
                  Conectamos estudiantes CIAF con empresas reales. Sin experiencia previa. Solo tu talento, habilidades y potencial.
                </p>

                <div style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap" }}>
                  <button onClick={() => setShowBuilder(true)} style={{ padding: "14px 32px", borderRadius: 12, border: "none", background: "#C8102E", color: "#fff", fontWeight: 800, fontSize: 15, cursor: "pointer", fontFamily: "inherit", boxShadow: "0 6px 20px rgba(200,16,46,0.25)" }}>
                    Crear mi perfil gratis →
                  </button>
                  <button onClick={() => setActiveTab("ofertas")} style={{ padding: "14px 32px", borderRadius: 12, border: "1.5px solid #DCDCDC", background: "#fff", color: "#333", fontWeight: 600, fontSize: 15, cursor: "pointer", fontFamily: "inherit" }}>
                    Ver ofertas →
                  </button>
                </div>
              </div>

              {/* Cards preview */}
              <div style={{ marginTop: 64, display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(280px, 1fr))", gap: 16 }}>
                {JOBS.slice(0, 3).map((job, i) => (
                  <div key={job.id} className="float" style={{ animationDelay: `${i * 0.35}s` }}>
                    <JobCard job={job} onApply={(j) => showNotif(`Postulación enviada a ${j.company}`)} />
                  </div>
                ))}
              </div>
            </div>

            {/* STATS STRIP */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 16, marginBottom: 80, background: "#1A1A1A", borderRadius: 20, padding: 36 }}>
              {STATS.map((s, i) => (
                <div key={i} style={{ textAlign: "center" }}>
                  <div className="syne" style={{ fontSize: 38, fontWeight: 800, color: i % 2 === 0 ? "#C8102E" : "#FF6B35" }}>{s.value}</div>
                  <div style={{ fontSize: 13, color: "#888", marginTop: 4 }}>{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* ═══ OFERTAS ══════════════════════════════════════════════════════ */}
        {activeTab === "ofertas" && (
          <div style={{ paddingTop: 48, paddingBottom: 80 }}>
            <div style={{ marginBottom: 32 }}>
              <h2 className="syne" style={{ fontSize: 34, fontWeight: 800, letterSpacing: -1, marginBottom: 6, color: "#1A1A1A" }}>Ofertas disponibles</h2>
              <p style={{ color: "#888", fontSize: 15 }}>{filteredJobs.length} oportunidades esperan tu postulación</p>
            </div>

            {/* Filtros */}
            <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 32, padding: "16px 20px", background: "#fff", borderRadius: 14, border: "1px solid #EBEBEB" }}>
              <span style={{ fontSize: 13, color: "#AAA", alignSelf: "center", fontWeight: 600 }}>Filtrar:</span>
              {["all", "Sistemas", "Diseño", "Contabilidad", "Marketing"].map(c => (
                <button key={c} onClick={() => setFilter(f => ({ ...f, career: c }))} style={{
                  padding: "6px 14px", borderRadius: 99,
                  border: `1px solid ${filter.career === c ? "#C8102E" : "#E0E0E0"}`,
                  background: filter.career === c ? "rgba(200,16,46,0.07)" : "none",
                  color: filter.career === c ? "#C8102E" : "#888",
                  fontSize: 12, fontWeight: 600, cursor: "pointer", fontFamily: "inherit",
                }}>{c === "all" ? "Todas" : c}</button>
              ))}
              <div style={{ width: 1, background: "#EBEBEB" }} />
              {["all", "Tiempo completo", "Medio tiempo", "Prácticas", "Freelance"].map(t => (
                <button key={t} onClick={() => setFilter(f => ({ ...f, type: t }))} style={{
                  padding: "6px 14px", borderRadius: 99,
                  border: `1px solid ${filter.type === t ? "#1A1A1A" : "#E0E0E0"}`,
                  background: filter.type === t ? "#1A1A1A" : "none",
                  color: filter.type === t ? "#fff" : "#888",
                  fontSize: 12, fontWeight: 600, cursor: "pointer", fontFamily: "inherit",
                }}>{t === "all" ? "Todos los tipos" : t}</button>
              ))}
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(300px, 1fr))", gap: 16 }}>
              {filteredJobs.map(job => (
                <JobCard key={job.id} job={job} onApply={(j) => showNotif(`Postulación enviada a ${j.company}`)} />
              ))}
            </div>

            {filteredJobs.length === 0 && (
              <div style={{ textAlign: "center", padding: 80, color: "#CCC" }}>
                <div style={{ fontSize: 48, marginBottom: 16 }}>🔍</div>
                <div className="syne" style={{ fontSize: 20, fontWeight: 700, color: "#AAA" }}>Sin resultados</div>
                <div style={{ fontSize: 14, marginTop: 8, color: "#CCC" }}>Intenta con otros filtros</div>
              </div>
            )}
          </div>
        )}

        {/* ═══ CÓMO FUNCIONA ════════════════════════════════════════════════ */}
        {activeTab === "como-funciona" && (
          <div style={{ paddingTop: 60, paddingBottom: 80 }}>
            <div style={{ textAlign: "center", marginBottom: 56 }}>
              <h2 className="syne" style={{ fontSize: 40, fontWeight: 800, letterSpacing: -1.5, marginBottom: 14, color: "#1A1A1A" }}>
                Del aula al trabajo,<br />
                <span style={{ color: "#C8102E" }}>en 4 pasos</span>
              </h2>
              <p style={{ color: "#888", fontSize: 16, maxWidth: 500, margin: "0 auto" }}>Un proceso diseñado para que el talento estudiantil CIAF brille sin necesitar años de experiencia.</p>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(240px, 1fr))", gap: 20, marginBottom: 56 }}>
              {STEPS.map((s, i) => (
                <div key={i} style={{ background: "#fff", border: "1.5px solid #EBEBEB", borderRadius: 20, padding: 28, position: "relative", overflow: "hidden" }}>
                  <div style={{ position: "absolute", top: -16, right: -12, fontSize: 80, opacity: 0.04, fontFamily: "'Syne', sans-serif", fontWeight: 900, color: "#1A1A1A" }}>{i + 1}</div>
                  <div style={{ fontSize: 36, marginBottom: 16 }}>{s.icon}</div>
                  <div className="syne" style={{ fontSize: 17, fontWeight: 700, marginBottom: 10, color: "#1A1A1A" }}>{s.title}</div>
                  <div style={{ fontSize: 14, color: "#888", lineHeight: 1.6 }}>{s.desc}</div>
                  <div style={{ position: "absolute", bottom: 0, left: 0, width: "100%", height: 3, background: ["#C8102E", "#1A1A1A", "#FF6B35", "#C8102E"][i] }} />
                </div>
              ))}
            </div>

            {/* Features */}
            <div style={{ background: "#1A1A1A", borderRadius: 24, padding: 40 }}>
              <h3 className="syne" style={{ fontSize: 24, fontWeight: 800, marginBottom: 28, letterSpacing: -0.5, color: "#fff" }}>Innovaciones de la plataforma</h3>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 20 }}>
                {[
                  { icon: "🤖", title: "Match automático", desc: "Conectamos tu perfil con las mejores ofertas de forma inteligente" },
                  { icon: "📂", title: "Portafolio digital", desc: "Muestra proyectos, evidencias y logros reales" },
                  { icon: "⭐", title: "Validación docente", desc: "Recomendaciones de tus profesores que avalan tus skills" },
                  { icon: "📊", title: "Retroalimentación", desc: "Las empresas te dan feedback para mejorar" },
                  { icon: "🏆", title: "Ranking estudiantil", desc: "Reputación basada en habilidades y evaluaciones" },
                  { icon: "🗺️", title: "Rutas de mejora", desc: "Plan personalizado para cerrar brechas de habilidades" },
                ].map((f, i) => (
                  <div key={i} style={{ display: "flex", gap: 14, alignItems: "flex-start" }}>
                    <div style={{ width: 40, height: 40, borderRadius: 10, background: i % 3 === 0 ? "#C8102E" : "rgba(255,255,255,0.07)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, flexShrink: 0 }}>{f.icon}</div>
                    <div>
                      <div style={{ fontSize: 14, fontWeight: 700, color: "#fff", marginBottom: 4 }}>{f.title}</div>
                      <div style={{ fontSize: 12, color: "#888", lineHeight: 1.5 }}>{f.desc}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* ═══ ESTADÍSTICAS ═════════════════════════════════════════════════ */}
        {activeTab === "estadisticas" && (
          <div style={{ paddingTop: 60, paddingBottom: 80 }}>
            <div style={{ textAlign: "center", marginBottom: 56 }}>
              <h2 className="syne" style={{ fontSize: 40, fontWeight: 800, letterSpacing: -1.5, marginBottom: 14, color: "#1A1A1A" }}>
                El <span style={{ color: "#C8102E" }}>impacto real</span>
              </h2>
              <p style={{ color: "#888", fontSize: 16 }}>Números que demuestran el valor de conectar talento CIAF con el mundo laboral.</p>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 16, marginBottom: 48 }}>
              {STATS.map((s, i) => (
                <div key={i} style={{ textAlign: "center", background: "#fff", border: "1.5px solid #EBEBEB", borderRadius: 20, padding: "32px 20px", boxShadow: "0 2px 8px rgba(0,0,0,0.04)" }}>
                  <div className="syne" style={{ fontSize: 44, fontWeight: 800, color: i % 2 === 0 ? "#C8102E" : "#1A1A1A" }}>
                    {s.value}
                  </div>
                  <div style={{ fontSize: 14, color: "#888", marginTop: 8 }}>{s.label}</div>
                </div>
              ))}
            </div>

            {/* Equipo */}
            <div style={{ background: "#fff", border: "1.5px solid #EBEBEB", borderRadius: 24, padding: 40 }}>
              <h3 className="syne" style={{ fontSize: 22, fontWeight: 800, marginBottom: 28, letterSpacing: -0.5, color: "#1A1A1A" }}>Equipo Bolsa de Empleo CIAF</h3>
              <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 16 }}>
                {[
                  { name: "María Fernanda", role: "Presentadora", icon: "🎤" },
                  { name: "Valeria Cuartas", role: "Presentadora", icon: "🎤" },
                  { name: "Juan Manuel", role: "Presentador", icon: "🎤" },
                  { name: "Samuel", role: "Desarrollador", icon: "💻" },
                  { name: "Nicolás", role: "Desarrollador", icon: "💻" },
                  { name: "Ana María", role: "Dev & Diseño", icon: "🎨" },
                  { name: "Luis Mario", role: "Desarrollador", icon: "💻" },
                  { name: "Camilo", role: "Desarrollador", icon: "💻" },
                  { name: "Ana María Toro", role: "Editora & Video", icon: "🎬" },
                  { name: "Danilo", role: "Video", icon: "🎬" },
                  { name: "Valeria", role: "Video", icon: "🎬" },
                  { name: "Mateo", role: "Guionista", icon: "✍️" },
                  { name: "Santiago", role: "Guionista", icon: "✍️" },
                  { name: "Alejandro", role: "Presentador", icon: "🎤" },
                ].map((m, i) => (
                  <div key={i} style={{ display: "flex", alignItems: "center", gap: 12 }}>
                    <div style={{ width: 40, height: 40, borderRadius: 10, background: i % 4 === 0 ? "#C8102E" : "#1A1A1A", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 18, flexShrink: 0 }}>{m.icon}</div>
                    <div>
                      <div style={{ fontSize: 13, fontWeight: 700, color: "#1A1A1A" }}>{m.name}</div>
                      <div style={{ fontSize: 11, color: "#AAA" }}>{m.role}</div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>

      {/* FOOTER */}
      <footer style={{ background: "#1A1A1A", padding: "36px 24px", textAlign: "center", marginTop: 20 }}>
        <div className="syne" style={{ fontSize: 17, fontWeight: 800, marginBottom: 8, color: "#fff" }}>
          Bolsa de Empleo <span style={{ color: "#C8102E" }}>CIAF</span>
        </div>
        <div style={{ fontSize: 12, color: "#555", marginBottom: 4 }}>
          "No eres un estudiante más, eres talento en desarrollo" — CIAF 2025
        </div>
        <div style={{ fontSize: 11, color: "#444" }}>
          © {new Date().getFullYear()} CIAF — Corporación Instituto de Administración y Finanzas · Pereira, Risaralda
        </div>
      </footer>
    </>
  );
}
